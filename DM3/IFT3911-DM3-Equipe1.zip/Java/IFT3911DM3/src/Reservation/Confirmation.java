package Reservation;

public class Confirmation {

	protected boolean confirmed;
	protected int numero;

	public int generateRandomnumber() {
		// TODO - implement Confirmation.generateRandomnumber
		throw new UnsupportedOperationException();
	}

}