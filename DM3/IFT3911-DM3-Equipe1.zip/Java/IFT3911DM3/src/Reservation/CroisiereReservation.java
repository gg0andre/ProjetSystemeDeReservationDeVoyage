package Reservation;

public class CroisiereReservation extends Reservation {
}