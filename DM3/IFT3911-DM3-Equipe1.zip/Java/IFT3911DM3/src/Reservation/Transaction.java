package Reservation;

public abstract class Transaction {

	CreditCardInfo creditcard;
	protected float amount;

}