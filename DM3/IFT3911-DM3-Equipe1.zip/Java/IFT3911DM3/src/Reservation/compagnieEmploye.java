package Reservation;

import Compagnie.*;

public class compagnieEmploye extends Personne {

	private Compagnie compagnie;
	private String username;
	private String password;
	private int idEmploye;

}