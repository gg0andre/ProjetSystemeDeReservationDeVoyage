package Reservation;

public abstract class Personne {

	protected String nom;
	protected String prenom;

}