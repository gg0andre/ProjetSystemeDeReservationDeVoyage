package Reservation;

public class VolReservation extends Reservation {
}