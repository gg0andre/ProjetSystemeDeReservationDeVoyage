package Reservation;

public class User extends Personne {

	private String username;
	private String password;
	private String courreil;
	private String numeroPasseport;

}