package Reservation;

import java.util.Calendar;

public class CreditCardInfo {

	private String cardHolderName;
	private long number;
	private int ccv;
	private Calendar expiration;

}