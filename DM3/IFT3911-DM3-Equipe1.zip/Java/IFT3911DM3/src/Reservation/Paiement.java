package Reservation;

public class Paiement extends Transaction {
}