package Reservation;

public class TrainReservation extends Reservation {
}