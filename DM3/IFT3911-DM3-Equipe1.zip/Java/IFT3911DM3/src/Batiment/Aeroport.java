package Batiment;

public class Aeroport extends Batiment {

	public Aeroport(String id, String ville) {
		super(id, ville);
		// TODO Auto-generated constructor stub
	}
}