package Batiment;

public class Gare extends Batiment {

	public Gare(String id, String ville) {
		super(id, ville);
		// TODO Auto-generated constructor stub
	}
}