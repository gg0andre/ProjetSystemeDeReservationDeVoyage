package Batiment;

public class Port extends Batiment {

	public Port(String id, String ville) {
		super(id, ville);
		// TODO Auto-generated constructor stub
	}
}