package CommandeFactory;

import Transport.*;

public class CreateVehicule implements ICommand {

	private Vehicule vehicule;
	private int vehiculeController;

	public void execute() {
		// TODO - implement CreateVehicule.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement CreateVehicule.undo
		throw new UnsupportedOperationException();
	}

}