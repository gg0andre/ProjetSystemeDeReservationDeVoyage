package CommandeFactory;

import Compagnie.*;

public class DeleteCompagnie implements ICommand {

	private Compagnie compagnie;
	private int compagnieController;

	public void execute() {
		// TODO - implement DeleteCompagnie.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement DeleteCompagnie.undo
		throw new UnsupportedOperationException();
	}

}