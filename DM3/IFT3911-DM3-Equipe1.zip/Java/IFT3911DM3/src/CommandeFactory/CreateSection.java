package CommandeFactory;

import Transport.*;

public class CreateSection implements ICommand {

	private Section section;
	private int sectionController;

	public void execute() {
		// TODO - implement CreateSection.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement CreateSection.undo
		throw new UnsupportedOperationException();
	}

}