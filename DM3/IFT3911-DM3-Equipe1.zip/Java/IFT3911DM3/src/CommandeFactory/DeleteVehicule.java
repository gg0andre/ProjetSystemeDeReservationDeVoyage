package CommandeFactory;

import Transport.*;

public class DeleteVehicule implements ICommand {

	private Vehicule vehicule;
	private int vehiculeController;

	public void execution() {
		// TODO - implement DeleteVehicule.execution
		throw new UnsupportedOperationException();
	}

	@Override
	public void execute() {

	}

	public void undo() {
		// TODO - implement DeleteVehicule.undo
		throw new UnsupportedOperationException();
	}

}