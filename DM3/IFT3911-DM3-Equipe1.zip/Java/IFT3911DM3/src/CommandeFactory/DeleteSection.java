package CommandeFactory;

import Transport.*;

public class DeleteSection implements ICommand {

	private Section section;
	private int sectionController;

	public void execute() {
		// TODO - implement DeleteSection.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement DeleteSection.undo
		throw new UnsupportedOperationException();
	}

}