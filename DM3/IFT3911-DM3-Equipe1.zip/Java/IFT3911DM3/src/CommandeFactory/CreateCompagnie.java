package CommandeFactory;

import Compagnie.*;

public class CreateCompagnie implements ICommand {

	private Compagnie compagnie;
	private int compagnieController;

	public void execute() {
		// TODO - implement CreateCompagnie.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement CreateCompagnie.undo
		throw new UnsupportedOperationException();
	}

}