package CommandeFactory;

public interface ICommand {

	void execute();

	void undo();

}