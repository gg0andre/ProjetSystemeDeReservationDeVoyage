package CommandeFactory;

import Batiment.*;

public class DeleteBatiment implements ICommand {

	private Batiment batiment;
	private int batimentController;

	public void execute() {
		// TODO - implement DeleteBatiment.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement DeleteBatiment.undo
		throw new UnsupportedOperationException();
	}

}