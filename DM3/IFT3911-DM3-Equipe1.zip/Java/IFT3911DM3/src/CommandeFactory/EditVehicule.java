package CommandeFactory;

import Transport.*;

public class EditVehicule implements ICommand {

	private Vehicule vehicule;
	private int vehiculeController;

	public void execution() {
		// TODO - implement EditVehicule.execution
		throw new UnsupportedOperationException();
	}

	@Override
	public void execute() {

	}

	public void undo() {
		// TODO - implement EditVehicule.undo
		throw new UnsupportedOperationException();
	}

}