package CommandeFactory;

import Transport.*;

public class EditSection implements ICommand {

	private Section section;
	private int sectionController;

	public void execute() {
		// TODO - implement EditSection.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement EditSection.undo
		throw new UnsupportedOperationException();
	}

}