package CommandeFactory;

import Compagnie.*;

public class EditCompagnie implements ICommand {

	private Compagnie compagnie;
	private int compagnieController;

	public void execute() {
		// TODO - implement EditCompagnie.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement EditCompagnie.undo
		throw new UnsupportedOperationException();
	}

}