package CommandeFactory;

import Batiment.*;

public class EditBatiment implements ICommand {

	private Batiment batiment;
	private int batimentController;

	public void execute() {
		// TODO - implement EditBatiment.execute
		throw new UnsupportedOperationException();
	}

	public void undo() {
		// TODO - implement EditBatiment.undo
		throw new UnsupportedOperationException();
	}

}