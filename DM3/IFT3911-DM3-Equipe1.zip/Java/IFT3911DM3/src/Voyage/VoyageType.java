package Voyage;

public enum VoyageType {
	Avion, Train, Bateau
}
