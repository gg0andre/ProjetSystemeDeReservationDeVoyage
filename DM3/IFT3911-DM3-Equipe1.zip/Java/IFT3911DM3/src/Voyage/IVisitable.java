package Voyage;

import Systeme.*;

public interface IVisitable {

	/**
	 * 
	 * @param v
	 */
	void accepte(Visiteur v);

}