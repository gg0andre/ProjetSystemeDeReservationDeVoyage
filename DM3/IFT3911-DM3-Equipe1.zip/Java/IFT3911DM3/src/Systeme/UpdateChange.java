package Systeme;

public class UpdateChange {

	private int menuUtilisateur;
	private int menuAdministrateur;
	private int voyageController;
	private int menuCompagnie;

	public void notifyAllUsers() {
		// TODO - implement UpdateChange.notifyAllUsers
		throw new UnsupportedOperationException();
	}

}