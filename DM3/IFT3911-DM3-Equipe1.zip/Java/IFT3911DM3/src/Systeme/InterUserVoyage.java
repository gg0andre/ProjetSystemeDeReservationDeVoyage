package Systeme;

import Voyage.*;
import Batiment.*;
import Compagnie.*;

import java.util.ArrayList;
import java.util.Calendar;


public class InterUserVoyage {

	private int voyageController;

	/**
	 * 
	 * @param id
	 */
	public Voyage readVoyage(int id) {
		// TODO - implement InterUserVoyage.readVoyage
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param depart
	 * @param date
	 */
	public Voyage consulterVoyage(Batiment depart, Calendar date) {
		// TODO - implement InterUserVoyage.consulterVoyage
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param c
	 */
	public ArrayList<Voyage> consulterVoyageCompagnie(Compagnie c) {
		// TODO - implement InterUserVoyage.consulterVoyageCompagnie
		throw new UnsupportedOperationException();
	}

}