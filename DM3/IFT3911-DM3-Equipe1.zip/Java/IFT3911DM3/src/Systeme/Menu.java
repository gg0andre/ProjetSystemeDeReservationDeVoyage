package Systeme;

public abstract class Menu {

	private int utilisateursController;
	private int batimentsController;
	private int compagniesController;
	private int voyagesController;

}