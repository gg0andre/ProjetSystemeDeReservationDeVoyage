package Systeme;

public interface Visiteur {
}