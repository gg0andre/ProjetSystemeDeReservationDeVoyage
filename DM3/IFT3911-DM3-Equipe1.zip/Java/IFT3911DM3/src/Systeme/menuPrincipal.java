package Systeme;

public class menuPrincipal extends Menu {

	public void selectMenu() {
		// TODO - implement menuPrincipal.selectMenu
		throw new UnsupportedOperationException();
	}

}