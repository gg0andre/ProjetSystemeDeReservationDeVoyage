package Systeme;

public class InterUserBatiment {

	private int batimentController;

	/**
	 * 
	 * @param id
	 */
	public void readBatiment(int id) {
		// TODO - implement InterUserBatiment.readBatiment
		throw new UnsupportedOperationException();
	}

}