package Systeme;

import Voyage.*;

public class VoyageVisiteur {

	/**
	 * 
	 * @param v
	 */
	public void visiteVoyage(Voyage v) {
		// TODO - implement VoyageVisiteur.visiteVoyage
		throw new UnsupportedOperationException();
	}

}