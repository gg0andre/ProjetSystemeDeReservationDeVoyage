package Controller;

import Transport.*;

public class SectionController extends Controller {

	public void add() {
		// TODO - implement SectionController.add
		throw new UnsupportedOperationException();
	}

	public void edit() {
		// TODO - implement SectionController.edit
		throw new UnsupportedOperationException();
	}

	public void delete() {
		// TODO - implement SectionController.delete
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param numero
	 */
	public Section readSection(int numero) {
		// TODO - implement SectionController.readSection
		throw new UnsupportedOperationException();
	}

}