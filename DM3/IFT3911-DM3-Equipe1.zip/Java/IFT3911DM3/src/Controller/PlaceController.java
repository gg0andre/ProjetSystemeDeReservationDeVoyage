package Controller;

import Transport.*;
import Compagnie.*;

public class PlaceController extends Controller {

	/**
	 * 
	 * @param id
	 * @param s
	 * @param v
	 * @param c
	 */
	public Place addPlace(int id, Section s, Vehicule v, Compagnie c) {
		// TODO - implement PlaceController.addPlace
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param etat
	 * @param p
	 * @param s
	 * @param v
	 * @param c
	 */
	public void editPlace(PlaceEtat etat, Place p, Section s, Vehicule v, Compagnie c) {
		// TODO - implement PlaceController.editPlace
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param s
	 * @param v
	 * @param c
	 */
	public Place readPlace(int id, Section s, Vehicule v, Compagnie c) {
		// TODO - implement PlaceController.readPlace
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param p
	 * @param s
	 * @param v
	 * @param c
	 */
	public void deletePlace(Place p, Section s, Vehicule v, Compagnie c) {
		// TODO - implement PlaceController.deletePlace
		throw new UnsupportedOperationException();
	}

}