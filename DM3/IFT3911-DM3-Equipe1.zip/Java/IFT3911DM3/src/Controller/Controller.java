package Controller;

public abstract class Controller {

	public void add() {
		// TODO - implement Controller.add
		throw new UnsupportedOperationException();
	}

	public void edit() {
		// TODO - implement Controller.edit
		throw new UnsupportedOperationException();
	}

	public void delete() {
		// TODO - implement Controller.delete
		throw new UnsupportedOperationException();
	}

}