package Controller;

import Reservation.*;

import java.util.Calendar;

public class UtilisateursController extends Controller {

	private Utilisateur[] listeUtilisateurs;

	public int createUser() {
		// TODO - implement UtilisateursController.createUser
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 */
	public void editUser(int id) {
		// TODO - implement UtilisateursController.editUser
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 */
	public void deleteUser(int id) {
		// TODO - implement UtilisateursController.deleteUser
		throw new UnsupportedOperationException();
	}

	public boolean createReservation() {
		// TODO - implement UtilisateursController.createReservation
		throw new UnsupportedOperationException();
	}

	public void deleteReservation() {
		// TODO - implement UtilisateursController.deleteReservation
		throw new UnsupportedOperationException();
	}

	public boolean editReservation() {
		// TODO - implement UtilisateursController.editReservation
		throw new UnsupportedOperationException();
	}

	public int confirmReservation() {
		// TODO - implement UtilisateursController.confirmReservation
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param chn
	 * @param n
	 * @param ccv
	 * @param exp
	 */
	public int payReservation(String chn, long n, int ccv, Calendar exp) {
		// TODO - implement UtilisateursController.payReservation
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param courreil
	 * @param Pass
	 */
	public Utilisateur readUser(String courreil, String Pass) {
		// TODO - implement UtilisateursController.readUser
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param password
	 */
	public boolean checkPassword(String password) {
		// TODO - implement UtilisateursController.checkPassword
		throw new UnsupportedOperationException();
	}

}