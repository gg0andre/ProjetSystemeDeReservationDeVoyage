package Transport;

public class Avion extends Vehicule {

	public Avion(String id, String nom) {
		super(id, nom);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param t
	 * @param rang�eD
	 * @param rang�eF
	 * @param prix
	 * @param disposition
	 */
	public void createSection(String t, int rang�eD, int rang�eF, int prix, String disposition) {
		// TODO - implement Avion.createSection
		throw new UnsupportedOperationException();
	}

}