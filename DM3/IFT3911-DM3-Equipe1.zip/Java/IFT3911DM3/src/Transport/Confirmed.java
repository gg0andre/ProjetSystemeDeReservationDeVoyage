package Transport;

public class Confirmed extends PlaceEtat {
}