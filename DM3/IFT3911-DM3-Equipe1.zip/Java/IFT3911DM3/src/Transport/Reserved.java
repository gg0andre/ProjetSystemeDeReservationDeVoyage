package Transport;

public class Reserved extends PlaceEtat {
}