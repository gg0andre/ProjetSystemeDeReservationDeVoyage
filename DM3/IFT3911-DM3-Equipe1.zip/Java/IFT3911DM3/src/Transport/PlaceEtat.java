package Transport;

public abstract class PlaceEtat {

	public void cancel() {
		// TODO - implement PlaceEtat.cancel
		throw new UnsupportedOperationException();
	}

	public void reserve() {
		// TODO - implement PlaceEtat.reserve
		throw new UnsupportedOperationException();
	}

	public boolean isAvailabke() {
		// TODO - implement PlaceEtat.isAvailabke
		throw new UnsupportedOperationException();
	}

}