package Transport;

public class Cabine extends Groupe {
}