package Transport;

public abstract class Individuel extends Place {
}