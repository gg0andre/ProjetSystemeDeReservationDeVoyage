package Transport;

public class SectionTrain extends IndividuelSection {
}