package Transport;

public abstract class GroupeSection extends Section {
}