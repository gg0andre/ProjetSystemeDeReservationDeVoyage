package Transport;

public class SiegeAvion extends Individuel {
}