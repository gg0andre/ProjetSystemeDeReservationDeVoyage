package Transport;

public class Available extends PlaceEtat {
}