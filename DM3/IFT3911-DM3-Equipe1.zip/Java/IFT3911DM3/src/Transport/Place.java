package Transport;

public abstract class Place {

	private int num�ro;
	PlaceEtat Etat;
	private double prixPlace;

	/**
	 * 
	 * @param etat
	 */
	public void setEtat(PlaceEtat etat) {
		// TODO - implement Place.setEtat
		throw new UnsupportedOperationException();
	}

	public PlaceEtat getEtat() {
		// TODO - implement Place.getEtat
		throw new UnsupportedOperationException();
	}

	public void update() {
		// TODO - implement Place.update
		throw new UnsupportedOperationException();
	}

}