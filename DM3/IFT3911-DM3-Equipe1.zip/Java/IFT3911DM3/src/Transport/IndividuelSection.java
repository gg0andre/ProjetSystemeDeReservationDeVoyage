package Transport;

public abstract class IndividuelSection extends Section {
}