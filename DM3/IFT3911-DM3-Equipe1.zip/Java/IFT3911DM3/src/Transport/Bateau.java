package Transport;

public class Bateau extends Vehicule {

	public Bateau(String id, String nom) {
		super(id, nom);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param t
	 * @param cabinesListe
	 */
	public void createSection(String t, int[] cabinesListe) {
		// TODO - implement Bateau.createSection
		throw new UnsupportedOperationException();
	}

}