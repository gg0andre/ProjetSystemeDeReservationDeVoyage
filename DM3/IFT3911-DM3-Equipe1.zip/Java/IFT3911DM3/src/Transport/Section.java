package Transport;

public abstract class Section {

	private int placesMax;
	private double prix;
	private int placesOccup�es;
	private int[] listePlaces;
	private int numeroSection;

	/**
	 * 
	 * @param num�ro
	 */
	public Place readPlace(int num�ro) {
		// TODO - implement Section.readPlace
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param numero
	 */
	public Place createPlace(int numero) {
		// TODO - implement Section.createPlace
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Place
	 * @param num�ro
	 */
	public void uptadePlace(int Place, int num�ro) {
		// TODO - implement Section.uptadePlace
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Place
	 */
	public void deletePlace(int Place) {
		// TODO - implement Section.deletePlace
		throw new UnsupportedOperationException();
	}

}