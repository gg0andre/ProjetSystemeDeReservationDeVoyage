package Transport;

public class SectionPaquebot extends GroupeSection {

	private int[] listePlaces;

}