package Transport;

public class Train extends Vehicule {

	public Train(String id, String nom) {
		super(id, nom);
		// TODO Auto-generated constructor stub
	}
}