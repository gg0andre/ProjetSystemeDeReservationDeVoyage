package Transport;

public class SiegeTrain extends Individuel {
}