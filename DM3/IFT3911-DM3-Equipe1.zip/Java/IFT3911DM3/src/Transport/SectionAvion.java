package Transport;

public class SectionAvion extends IndividuelSection {
}