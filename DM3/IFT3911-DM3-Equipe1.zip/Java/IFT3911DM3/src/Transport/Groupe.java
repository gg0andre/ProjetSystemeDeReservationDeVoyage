package Transport;

public abstract class Groupe extends Place {
}