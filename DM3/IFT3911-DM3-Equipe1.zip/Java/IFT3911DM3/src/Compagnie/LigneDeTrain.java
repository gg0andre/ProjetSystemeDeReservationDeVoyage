package Compagnie;

public class LigneDeTrain extends Compagnie {

	public LigneDeTrain(String id, String nom) {
		super(id, nom);
		// TODO Auto-generated constructor stub
	}
}