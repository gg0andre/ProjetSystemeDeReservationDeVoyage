package Compagnie;

public class CompagnieDeCroisiere extends Compagnie {

	public CompagnieDeCroisiere(String id, String nom) {
		super(id, nom);
		// TODO Auto-generated constructor stub
	}
}