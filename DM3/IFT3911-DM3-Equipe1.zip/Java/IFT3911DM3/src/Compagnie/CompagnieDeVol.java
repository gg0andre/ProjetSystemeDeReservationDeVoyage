package Compagnie;

public class CompagnieDeVol extends Compagnie {
	
	public CompagnieDeVol(String id, String nom) {
		super(id, nom);
	}
}