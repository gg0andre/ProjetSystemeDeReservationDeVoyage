Seulement André et Abderrahim ont travailé sur le code.
On n'a pas fait beaucoup. Les seules fontionnalités (fait par André) qui fonctionnent sont la création des Batiments (aéroport, port et gare) et
la création des Compagnies (compagnie de vol, compagnie de croisière et ligne de train). Le patron de fabriques (fait par André) réalise la création
des objets concrètes. 